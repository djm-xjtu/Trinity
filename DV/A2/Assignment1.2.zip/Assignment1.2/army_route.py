import pandas as pd
import altair as alt

data_xlsx = pd.read_excel("data/minard-data.xlsx")
# Data of cities
cities = data_xlsx.loc[:, ['LONC', 'LATC', 'CITY']]
cities = cities.dropna()
# print positions of cities
cityPositions = alt.Chart(cities).mark_text(fontSize=16).encode(
    longitude="LONC", latitude="LATC", text="CITY"
)

army = data_xlsx.loc[:, ['LONP', 'LATP', 'SURV', 'DIR', 'DIV']]

# print route of army
color = alt.Color("DIR", scale=alt.Scale(domain=["Advancing", "Retreating"], range=["#DDAA00", "#444444"]), title="Direction")
size = alt.Size('SURV', scale=alt.Scale(range=[5, 60]), title="Survival")
armyData = alt.Chart(army).mark_trail().encode(
    longitude='LONP', latitude='LATP', detail="DIV", color=color, size=size
)

alt.vconcat(armyData + cityPositions).configure_view(width=1100, height=500, strokeWidth=0).save("army.html")
