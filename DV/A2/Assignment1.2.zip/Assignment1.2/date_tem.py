import pandas as pd
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

data_xlsx = pd.read_excel("data/minard-data.xlsx")
tem = data_xlsx.loc[:, ['TEMP', 'DAY', 'MON']]
date = []
for i in range(9):
    date.append(str(int(tem["DAY"][i])) + ' ' + str(tem["MON"][i]))

date.reverse()
x = [0, 1, 6, 9, 13, 23, 28, 43, 49]
for i in range(len(x)):
    x[i] *= 2
temp = []
for i in range(9):
    temp.append(tem["TEMP"][i])
temp.reverse()
for i in range(9):
    plt.text(x[i]-1, temp[i]+0.5, date[i])
plt.xlabel("date")
plt.ylabel("temperature ℃")

plt.plot(x, temp, color="black")
plt.show()